-- MariaDB dump 10.19  Distrib 10.5.15-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: database    Database: webWMS
-- ------------------------------------------------------
-- Server version	10.5.16-MariaDB-1:10.5.16+maria~focal

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_nr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `article_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `article_category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `article_weight` decimal(10,2) NOT NULL,
  `article_ean` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `article_unit` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `article_depth` decimal(6,2) NOT NULL,
  `article_width` decimal(6,2) NOT NULL,
  `article_height` decimal(6,2) NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'60004','Telefon MBO Alpha 1600 CT','DECT-Telefone',1.50,'4260151600048','Stk',250.00,110.00,150.00),(2,'60008','Telefon MBO Alpha 1650 CT','DECT-Telefone',1.50,'4260151600083','Stk',250.00,110.00,150.00),(3,'90001','Monitor LG 22MK600M-B LED 21.5 Zoll Full-HD','Monitore',3.70,'8806098206001','Stk',363.00,561.00,139.00),(4,'80025','Desktop PC Aspire XC-885 - Schwarz','Desktop PCs',7.00,'4710180084016','Stk',497.00,170.00,405.00),(5,'71105','Notebook Asus VivoBook 17 F705UA-BX831T - Grau','Notebooks',4.30,'4718017246217','Stk',497.00,533.00,75.00),(6,'90002','Testartikel','Test',1.50,'4235126423250','Stk',250.00,250.00,250.00);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_method`
--

DROP TABLE IF EXISTS `booking_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_method` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bm_short` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bm_desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_method`
--

LOCK TABLES `booking_method` WRITE;
/*!40000 ALTER TABLE `booking_method` DISABLE KEYS */;
INSERT INTO `booking_method` VALUES (101,'IN101','Einlagern direkt'),(102,'IN102','WE zur Bestellung'),(201,'WA201','Auslagern direkt'),(202,'WA202','Auslagern Auftrag-Position');
/*!40000 ALTER TABLE `booking_method` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `customer_nr` int(11) NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address_addition` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address_street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address_street_nr` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_country_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_zip_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,1,60000,'ALDI Zeven','Filiale Zeven','Nord-West-Ring','5','DE','27404','Zeven'),(2,2,60001,'ALDI Buxtehude','Filiale Buxtehude','Stader Straße','10','DE','21614','Buxtehude'),(3,3,60002,'ALDI Harsefeld','Filiale Harsefeld','Paschberg','22','DE','21698','Harsefeld'),(4,4,60003,'ALDI Hamburg-Winterhude','Filiale Hamburg-Winterhude','Barmbeker Straße','17-25','DE','22303','Hamburg'),(5,5,60004,'ALDI Wismar','Filiale Wismar','Bürgermeister-Haupt-Straße','56','DE','23966','Wismar'),(6,6,60005,'ALDI Usedom','Filiale Usedom','Bäderstraße','3','DE','17406','Usedom'),(7,7,60006,'ALDI Schwerin','Filiale Schwerin','Am Margaretenhof','12','DE','19057','Schwerin'),(8,8,60008,'ALDI Rostock-Warnemünde','Filiale Rostock-Warnemünde','Lortzing Straße','19a','DE','18119','Rostock'),(9,9,60009,'ALDI Stralsund','Filiale Stralsund','Gustower Weg','3','DE','18439','Stralsund'),(10,10,60010,'ALDI Greifswald','Filiale Greifswald','Bahnhofstraße','44','DE','17489','Greifswald'),(11,11,60011,'LIDL Usedom','Filiale Heringsdorf','Ahlbecker Chaussee','9','DE','17429','Heringsdorf'),(12,12,60012,'LIDL Schwerin','Filiale Schwerin','Greifswalder Straße','1','DE','19057','Schwerin'),(13,13,60013,'LIDL Stralsund','Filiale Stralsund','Feldstraße','1','DE','18437','Stralsund'),(14,14,60014,'LIDL Buxtehude','Filiale Buxtehude','Bei der Fischtreppe','2','DE','21614','Buxtehude'),(15,15,60015,'LIDL Greifswald','Filiale Greifswald','Anklamer Straße','30','DE','17489','Greifswald'),(16,16,60016,'LIDL Zeven','Filiale Zeven','Kivinanstraße','41','DE','27404','Zeven'),(17,17,60017,'LIDL Rostock','Filiale Rostock','Neubrandenburger Straße','10','DE','18055','Rostock'),(18,18,60018,'LIDL Harsefeld','Filiale Harsefeld','Buxtehudeer Straße','17','DE','21698','Harsefeld'),(19,19,60019,'LIDL Hamburg','Filiale Hamburg','Borgweg','2a','DE','22303','Hamburg'),(20,20,60020,'LIDL Wismar','Filiale Wismar','Am Wiesengrund','3','DE','23970','Wismar'),(21,21,60021,'ALDI Stade','Filiale Stade','Am Steinkamp','3','DE','21684','Stade');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_order_pos`
--

DROP TABLE IF EXISTS `customer_order_pos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_order_pos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_order_id` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  `customer_order_pos_quantity` decimal(11,3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_order_pos`
--

LOCK TABLES `customer_order_pos` WRITE;
/*!40000 ALTER TABLE `customer_order_pos` DISABLE KEYS */;
INSERT INTO `customer_order_pos` VALUES (1,710001,1,80.000),(2,710001,2,80.000),(3,710002,1,80.000),(4,710002,2,80.000),(5,710003,1,80.000),(6,710003,2,80.000),(7,710004,1,80.000),(8,710004,2,80.000),(9,710005,1,80.000),(10,710005,2,80.000),(11,710006,1,80.000),(12,710006,2,80.000),(13,710007,1,80.000),(14,710007,2,80.000),(15,710008,1,80.000),(16,710008,2,80.000),(17,710009,1,80.000),(18,710009,2,80.000),(19,710010,1,80.000),(20,710010,2,80.000),(21,710011,4,40.000),(22,710011,5,40.000),(23,710012,4,40.000),(24,710012,5,40.000),(25,710013,4,40.000),(26,710013,5,40.000),(27,710014,4,40.000),(28,710014,5,40.000),(29,710015,4,40.000),(30,710015,5,40.000),(31,710016,4,40.000),(32,710016,5,40.000),(33,710017,4,40.000),(34,710017,5,40.000),(35,710018,4,40.000),(36,710018,5,40.000),(37,710019,4,40.000),(38,710019,5,40.000),(39,710020,4,40.000),(40,710020,5,40.000);
/*!40000 ALTER TABLE `customer_order_pos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_orders`
--

DROP TABLE IF EXISTS `customer_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_order_id` int(11) NOT NULL,
  `usr_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_order_nr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_order_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_order_date` datetime DEFAULT NULL,
  `customer_order_order_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=710021 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_orders`
--

LOCK TABLES `customer_orders` WRITE;
/*!40000 ALTER TABLE `customer_orders` DISABLE KEYS */;
INSERT INTO `customer_orders` VALUES (710001,710001,4,1,'VLS-01-710001','Telefon Aktion ALDI, Filiale Zeven','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710002,710002,2,2,'VLS-01-710002','Telefon Aktion ALDI, Filiale Buxtehude','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710003,710003,3,3,'VLS-01-710003','Telefon Aktion ALDI, Filiale Harsefeld','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710004,710004,2,4,'VLS-01-710004','Telefon Aktion ALDI, Filiale Hamburg','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710005,710005,4,5,'VLS-01-710005','Telefon Aktion ALDI, Filiale Wismar','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710006,710006,4,6,'VLS-01-710006','Telefon Aktion ALDI, Filiale Usedom','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710007,710007,3,7,'VLS-01-710007','Telefon Aktion ALDI, Filiale Schwerin','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710008,710008,4,8,'VLS-01-710008','Telefon Aktion ALDI, Filiale Rostock','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710009,710009,2,9,'VLS-01-710009','Telefon Aktion ALDI, Filiale Stralsund','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710010,710010,3,10,'VLS-01-710010','Telefon Aktion ALDI, Filiale Greifswald','2019-06-01 00:00:00','2019-03-01 00:00:00'),(710011,710011,4,11,'VLS-01-710011','PC Aktion LIDL, Filiale Usedom','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710012,710012,2,12,'VLS-01-710012','PC Aktion LIDL, Filiale Schwerin','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710013,710013,2,13,'VLS-01-710013','PC Aktion LIDL, Filiale Stralsund','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710014,710014,3,14,'VLS-01-710014','PC Aktion LIDL, Filiale Buxtehude','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710015,710015,4,15,'VLS-01-710015','PC Aktion LIDL, Filiale Greifswald','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710016,710016,2,16,'VLS-01-710016','PC Aktion LIDL, Filiale Zeven','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710017,710017,3,17,'VLS-01-710017','PC Aktion LIDL, Filiale Rostock','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710018,710018,4,18,'VLS-01-710018','PC Aktion LIDL, Filiale Harsefeld','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710019,710019,2,19,'VLS-01-710019','PC Aktion LIDL, Filiale Hamburg','2019-03-15 00:00:00','2019-03-01 00:00:00'),(710020,710020,4,20,'VLS-01-710020','PC Aktion LIDL, Filiale Wismar','2019-03-15 00:00:00','2019-03-01 00:00:00');
/*!40000 ALTER TABLE `customer_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_layout`
--

DROP TABLE IF EXISTS `stock_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_layout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_nr` int(11) NOT NULL,
  `stock_description` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_level1` int(11) NOT NULL,
  `stock_level2` int(11) NOT NULL,
  `stock_level3` int(11) NOT NULL,
  `stock_level4` int(11) NOT NULL,
  `stock_model` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_typ` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_long_description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_layout`
--

LOCK TABLES `stock_layout` WRITE;
/*!40000 ALTER TABLE `stock_layout` DISABLE KEYS */;
INSERT INTO `stock_layout` VALUES (1,101,'Block',1,9,32,1,'L2','BLL','Block'),(2,104,'Block',1,15,52,1,'L2','BLL','Block'),(3,105,'Block',1,11,52,1,'L2','BLL','Block'),(4,106,'Block',1,3,52,1,'L2','BLL','Block'),(5,107,'Block',1,9,40,1,'L2','BLL','Block'),(6,108,'Block',1,11,40,1,'L2','BLL','Block'),(7,109,'Block',1,3,40,1,'L2','BLL','Block'),(8,120,'Pal Regal',2,24,1,1,'L2','HRL','Pal Regal'),(9,131,'Pal Regal',4,15,1,1,'L2','HRL','Pal Regal'),(10,132,'Pal Regal',4,12,1,1,'L2','HRL','Pal Regal'),(11,133,'Pal Regal',4,12,1,1,'L2','HRL','Pal Regal'),(12,134,'Pal Regal',4,12,1,1,'L2','HRL','Pal Regal'),(13,135,'Pal Regal',4,12,1,1,'L2','HRL','Pal Regal'),(14,136,'Pal Regal',4,12,1,1,'L2','HRL','Pal Regal'),(15,137,'Pal Regal',4,12,1,1,'L2','HRL','Pal Regal'),(16,141,'Pal Regal',4,33,1,1,'L2','HRL','Pal Regal'),(17,142,'Pal Regal',4,30,1,1,'L2','HRL','Pal Regal'),(18,143,'Pal Regal',4,30,1,1,'L2','HRL','Pal Regal'),(19,144,'Pal Regal',4,30,1,1,'L2','HRL','Pal Regal'),(20,145,'Pal Regal',4,30,1,1,'L2','HRL','Pal Regal'),(21,146,'Pal Regal',4,30,1,1,'L2','HRL','Pal Regal'),(22,147,'Pal Regal',4,30,1,1,'L2','HRL','Pal Regal'),(23,156,'Durchlaufregal',4,9,60,1,'L2','RGL','Durchlaufregal'),(24,157,'Durchlaufregal',4,9,60,1,'L2','RGL','Durchlaufregal'),(25,158,'Durchlaufregal',4,9,60,1,'L2','RGL','Durchlaufregal'),(26,159,'Durchlaufregal',4,9,60,1,'L2','LV','Durchlaufregal'),(27,160,'Konfektion',1,1,1,1,'L1','UBZ','Konfektionierung'),(28,163,'KOMMI',1,1,1,1,'L1','KML','Kommisionierung ganze LE'),(29,165,'WA-KEP',1,1,1,1,'L1','WAZ','Warenausgang KEP'),(30,170,'WA-SPED',1,1,1,1,'L1','WAZ','Warenausgang Stückgut'),(31,202,'Block',1,5,24,1,'L2','BLL','Block'),(32,203,'Block',1,4,40,1,'L2','BLL','Block'),(33,204,'Block',1,4,24,1,'L2','BLL','Block'),(34,205,'Block',1,4,40,1,'L2','BLL','Block'),(35,206,'Block',1,11,24,1,'L2','BLL','Block'),(36,207,'Block',1,6,24,1,'L2','BLL','Block'),(37,301,'Block',1,5,8,1,'L2','BLL','Block'),(38,305,'Block',1,19,40,1,'L2','BLL','Block'),(39,307,'Block',1,5,40,1,'L2','BLL','Block'),(40,308,'Block',1,7,40,1,'L2','BLL','Block'),(41,309,'Block',1,5,40,1,'L2','BLL','Block'),(42,310,'Block',1,6,8,1,'L2','BLL','Block'),(43,311,'Block',1,4,8,1,'L2','BLL','Block'),(44,312,'Block',1,5,40,1,'L2','BLL','Block'),(45,313,'Block',1,7,40,1,'L2','BLL','Block'),(46,314,'Block',1,5,40,1,'L2','BLL','Block'),(47,316,'Block',1,7,8,1,'L2','BLL','Block'),(48,317,'Block',1,5,36,1,'L2','BLL','Block'),(49,318,'Block',1,7,36,1,'L2','BLL','Block'),(50,319,'Block',1,5,36,1,'L2','BLL','Block'),(51,320,'Block',1,6,8,1,'L2','BLL','Block'),(52,322,'Block',1,5,36,1,'L2','BLL','Block'),(53,323,'Block',1,7,36,1,'L2','BLL','Block'),(54,324,'Block',1,5,36,1,'L2','BLL','Block'),(55,325,'Block',1,21,36,1,'L2','BLL','Block');
/*!40000 ALTER TABLE `stock_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_location`
--

DROP TABLE IF EXISTS `stock_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_location_ln` int(11) NOT NULL,
  `stock_location_fb` int(11) NOT NULL,
  `stock_location_sp` int(11) NOT NULL,
  `stock_location_tf` int(11) NOT NULL,
  `stock_location_coordinate` bigint(20) NOT NULL,
  `stock_location_desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_location_width` decimal(6,2) NOT NULL,
  `stock_location_depth` decimal(6,2) NOT NULL,
  `stock_location_height` decimal(6,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_location`
--

LOCK TABLES `stock_location` WRITE;
/*!40000 ALTER TABLE `stock_location` DISABLE KEYS */;
INSERT INTO `stock_location` VALUES (1,101,1,1,1,101000100010001,'Block-Lager',800.00,1200.00,2000.00),(2,101,1,1,2,101000100010002,'Block-Lager',800.00,1200.00,2000.00),(3,101,1,1,3,101000100010003,'Block-Lager',800.00,1200.00,2000.00),(4,101,1,1,4,101000100010004,'Block-Lager',800.00,1200.00,2000.00),(5,101,1,1,5,101000100010005,'Block-Lager',800.00,1200.00,2000.00),(6,101,1,1,6,101000100010006,'Block-Lager',800.00,1200.00,2000.00),(7,101,1,1,7,101000100010007,'Block-Lager',800.00,1200.00,2000.00),(8,101,1,1,8,101000100010008,'Block-Lager',800.00,1200.00,2000.00),(9,101,1,1,9,101000100010009,'Block-Lager',800.00,1200.00,2000.00),(10,101,1,1,10,101000100010010,'Block-Lager',800.00,1200.00,2000.00),(11,101,1,1,11,101000100010011,'Block-Lager',800.00,1200.00,2000.00),(12,101,1,1,12,101000100010012,'Block-Lager',800.00,1200.00,2000.00),(13,101,1,1,13,101000100010013,'Block-Lager',800.00,1200.00,2000.00),(14,101,1,1,14,101000100010014,'Block-Lager',800.00,1200.00,2000.00),(15,101,1,1,15,101000100010015,'Block-Lager',800.00,1200.00,2000.00),(16,101,1,1,16,101000100010016,'Block-Lager',800.00,1200.00,2000.00),(17,101,1,1,17,101000100010017,'Block-Lager',800.00,1200.00,2000.00),(18,101,1,1,18,101000100010018,'Block-Lager',800.00,1200.00,2000.00),(19,101,1,1,19,101000100010019,'Block-Lager',800.00,1200.00,2000.00),(20,101,1,1,20,101000100010020,'Block-Lager',800.00,1200.00,2000.00),(21,101,1,1,21,101000100010021,'Block-Lager',800.00,1200.00,2000.00),(22,101,1,1,22,101000100010022,'Block-Lager',800.00,1200.00,2000.00),(23,101,1,1,23,101000100010023,'Block-Lager',800.00,1200.00,2000.00),(24,101,1,1,24,101000100010024,'Block-Lager',800.00,1200.00,2000.00),(25,101,1,1,25,101000100010025,'Block-Lager',800.00,1200.00,2000.00),(26,101,1,1,26,101000100010026,'Block-Lager',800.00,1200.00,2000.00),(27,101,1,1,27,101000100010027,'Block-Lager',800.00,1200.00,2000.00),(28,101,1,1,28,101000100010028,'Block-Lager',800.00,1200.00,2000.00),(29,101,1,1,29,101000100010029,'Block-Lager',800.00,1200.00,2000.00),(30,101,1,1,30,101000100010030,'Block-Lager',800.00,1200.00,2000.00),(31,101,1,2,1,101000100020001,'Block-Lager',800.00,1200.00,2000.00),(32,101,1,2,2,101000100020002,'Block-Lager',800.00,1200.00,2000.00),(33,101,1,2,3,101000100020003,'Block-Lager',800.00,1200.00,2000.00),(34,101,1,2,4,101000100020004,'Block-Lager',800.00,1200.00,2000.00),(35,101,1,2,5,101000100020005,'Block-Lager',800.00,1200.00,2000.00),(36,101,1,2,6,101000100020006,'Block-Lager',800.00,1200.00,2000.00),(37,101,1,2,7,101000100020007,'Block-Lager',800.00,1200.00,2000.00),(38,101,1,2,8,101000100020008,'Block-Lager',800.00,1200.00,2000.00),(39,101,1,2,9,101000100020009,'Block-Lager',800.00,1200.00,2000.00),(40,101,1,2,10,101000100020010,'Block-Lager',800.00,1200.00,2000.00),(41,101,1,2,11,101000100020011,'Block-Lager',800.00,1200.00,2000.00),(42,101,1,2,12,101000100020012,'Block-Lager',800.00,1200.00,2000.00),(43,101,1,2,13,101000100020013,'Block-Lager',800.00,1200.00,2000.00),(44,101,1,2,14,101000100020014,'Block-Lager',800.00,1200.00,2000.00),(45,101,1,2,15,101000100020015,'Block-Lager',800.00,1200.00,2000.00),(46,101,1,2,16,101000100020016,'Block-Lager',800.00,1200.00,2000.00),(47,101,1,2,17,101000100020017,'Block-Lager',800.00,1200.00,2000.00),(48,101,1,2,18,101000100020018,'Block-Lager',800.00,1200.00,2000.00),(49,101,1,2,19,101000100020019,'Block-Lager',800.00,1200.00,2000.00),(50,101,1,2,20,101000100020020,'Block-Lager',800.00,1200.00,2000.00),(51,101,1,2,21,101000100020021,'Block-Lager',800.00,1200.00,2000.00),(52,101,1,2,22,101000100020022,'Block-Lager',800.00,1200.00,2000.00),(53,101,1,2,23,101000100020023,'Block-Lager',800.00,1200.00,2000.00),(54,101,1,2,24,101000100020024,'Block-Lager',800.00,1200.00,2000.00),(55,101,1,2,25,101000100020025,'Block-Lager',800.00,1200.00,2000.00),(56,101,1,2,26,101000100020026,'Block-Lager',800.00,1200.00,2000.00),(57,101,1,2,27,101000100020027,'Block-Lager',800.00,1200.00,2000.00),(58,101,1,2,28,101000100020028,'Block-Lager',800.00,1200.00,2000.00),(59,101,1,2,29,101000100020029,'Block-Lager',800.00,1200.00,2000.00),(60,101,1,2,30,101000100020030,'Block-Lager',800.00,1200.00,2000.00),(61,141,1,1,1,141000100010001,'Pal Regal',800.00,1200.00,1800.00),(62,141,1,2,1,141000100020001,'Pal Regal',800.00,1200.00,1800.00),(63,141,1,3,1,141000100030001,'Pal Regal',800.00,1200.00,1800.00),(64,141,1,4,1,141000100040001,'Pal Regal',800.00,1200.00,1800.00),(65,141,1,5,1,141000100050001,'Pal Regal',800.00,1200.00,1800.00),(66,141,1,6,1,141000100060001,'Pal Regal',800.00,1200.00,1800.00),(67,141,1,7,1,141000100070001,'Pal Regal',800.00,1200.00,1800.00),(68,141,1,8,1,141000100080001,'Pal Regal',800.00,1200.00,1800.00),(69,141,1,9,1,141000100090001,'Pal Regal',800.00,1200.00,1800.00),(70,141,1,10,1,141000100100001,'Pal Regal',800.00,1200.00,1800.00),(71,141,1,11,1,141000100110001,'Pal Regal',800.00,1200.00,1800.00),(72,141,1,12,1,141000100120001,'Pal Regal',800.00,1200.00,1800.00),(73,141,1,13,1,141000100130001,'Pal Regal',800.00,1200.00,1800.00),(74,141,1,14,1,141000100140001,'Pal Regal',800.00,1200.00,1800.00),(75,141,1,15,1,141000100150001,'Pal Regal',800.00,1200.00,1800.00),(76,141,2,1,1,141000200010001,'Pal Regal',800.00,1200.00,1800.00),(77,141,2,2,1,141000200020001,'Pal Regal',800.00,1200.00,1800.00),(78,141,2,3,1,141000200030001,'Pal Regal',800.00,1200.00,1800.00),(79,141,2,4,1,141000200040001,'Pal Regal',800.00,1200.00,1800.00),(80,141,2,5,1,141000200050001,'Pal Regal',800.00,1200.00,1800.00),(81,141,2,6,1,141000200060001,'Pal Regal',800.00,1200.00,1800.00),(82,141,2,7,1,141000200070001,'Pal Regal',800.00,1200.00,1800.00),(83,141,2,8,1,141000200080001,'Pal Regal',800.00,1200.00,1800.00),(84,141,2,9,1,141000200090001,'Pal Regal',800.00,1200.00,1800.00),(85,141,2,10,1,141000200100001,'Pal Regal',800.00,1200.00,1800.00),(86,141,2,11,1,141000200110001,'Pal Regal',800.00,1200.00,1800.00),(87,141,2,12,1,141000200120001,'Pal Regal',800.00,1200.00,1800.00),(88,141,2,13,1,141000200130001,'Pal Regal',800.00,1200.00,1800.00),(89,141,2,14,1,141000200140001,'Pal Regal',800.00,1200.00,1800.00),(90,141,2,15,1,141000200150001,'Pal Regal',800.00,1200.00,1800.00),(91,151,1,1,1,151000100010001,'Durchlaufregal',400.00,400.00,300.00),(92,151,1,2,1,151000100020001,'Durchlaufregal',400.00,400.00,300.00),(93,151,1,3,1,151000100030001,'Durchlaufregal',400.00,400.00,300.00),(94,151,1,4,1,151000100040001,'Durchlaufregal',400.00,400.00,300.00),(95,151,1,5,1,151000100050001,'Durchlaufregal',400.00,400.00,300.00),(96,151,1,6,1,151000100060001,'Durchlaufregal',400.00,400.00,300.00),(97,151,1,7,1,151000100070001,'Durchlaufregal',400.00,400.00,300.00),(98,151,1,8,1,151000100080001,'Durchlaufregal',400.00,400.00,300.00),(99,151,1,9,1,151000100090001,'Durchlaufregal',400.00,400.00,300.00),(100,151,1,10,1,151000100100001,'Durchlaufregal',400.00,400.00,300.00),(101,151,2,1,1,151000200010001,'Durchlaufregal',400.00,400.00,300.00),(102,151,2,2,1,151000200020001,'Durchlaufregal',400.00,400.00,300.00),(103,151,2,3,1,151000200030001,'Durchlaufregal',400.00,400.00,300.00),(104,151,2,4,1,151000200040001,'Durchlaufregal',400.00,400.00,300.00),(105,151,2,5,1,151000200050001,'Durchlaufregal',400.00,400.00,300.00),(106,151,2,6,1,151000200060001,'Durchlaufregal',400.00,400.00,300.00),(107,151,2,7,1,151000200070001,'Durchlaufregal',400.00,400.00,300.00),(108,151,2,8,1,151000200080001,'Durchlaufregal',400.00,400.00,300.00),(109,151,2,9,1,151000200090001,'Durchlaufregal',400.00,400.00,300.00),(110,151,2,10,1,151000200100001,'Durchlaufregal',400.00,400.00,300.00),(111,151,3,1,1,151000300010001,'Durchlaufregal',400.00,400.00,300.00),(112,151,3,2,1,151000300020001,'Durchlaufregal',400.00,400.00,300.00),(113,151,3,3,1,151000300030001,'Durchlaufregal',400.00,400.00,300.00),(114,151,3,4,1,151000300040001,'Durchlaufregal',400.00,400.00,300.00),(115,151,3,5,1,151000300050001,'Durchlaufregal',400.00,400.00,300.00),(116,151,3,6,1,151000300060001,'Durchlaufregal',400.00,400.00,300.00),(117,151,3,7,1,151000300070001,'Durchlaufregal',400.00,400.00,300.00),(118,151,3,8,1,151000300080001,'Durchlaufregal',400.00,400.00,300.00),(119,151,3,9,1,151000300090001,'Durchlaufregal',400.00,400.00,300.00),(120,151,3,10,1,151000300100001,'Durchlaufregal',400.00,400.00,300.00),(121,151,4,1,1,151000400010001,'Durchlaufregal',400.00,400.00,300.00),(122,151,4,2,1,151000400020001,'Durchlaufregal',400.00,400.00,300.00),(123,151,4,3,1,151000400030001,'Durchlaufregal',400.00,400.00,300.00),(124,151,4,4,1,151000400040001,'Durchlaufregal',400.00,400.00,300.00),(125,151,4,5,1,151000400050001,'Durchlaufregal',400.00,400.00,300.00),(126,151,4,6,1,151000400060001,'Durchlaufregal',400.00,400.00,300.00),(127,151,4,7,1,151000400070001,'Durchlaufregal',400.00,400.00,300.00),(128,151,4,8,1,151000400080001,'Durchlaufregal',400.00,400.00,300.00),(129,151,4,9,1,151000400090001,'Durchlaufregal',400.00,400.00,300.00),(130,151,4,10,1,151000400100001,'Durchlaufregal',400.00,400.00,300.00),(131,151,5,1,1,151000500010001,'Durchlaufregal',400.00,400.00,300.00),(132,151,5,2,1,151000500020001,'Durchlaufregal',400.00,400.00,300.00),(133,151,5,3,1,151000500030001,'Durchlaufregal',400.00,400.00,300.00),(134,151,5,4,1,151000500040001,'Durchlaufregal',400.00,400.00,300.00),(135,151,5,5,1,151000500050001,'Durchlaufregal',400.00,400.00,300.00),(136,151,5,6,1,151000500060001,'Durchlaufregal',400.00,400.00,300.00),(137,151,5,7,1,151000500070001,'Durchlaufregal',400.00,400.00,300.00),(138,151,5,8,1,151000500080001,'Durchlaufregal',400.00,400.00,300.00),(139,151,5,9,1,151000500090001,'Durchlaufregal',400.00,400.00,300.00),(140,151,5,10,1,151000500100001,'Durchlaufregal',400.00,400.00,300.00);
/*!40000 ALTER TABLE `stock_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_rotation`
--

DROP TABLE IF EXISTS `stock_rotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_rotation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_location_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `usr_id` int(11) DEFAULT NULL,
  `customer_order_id` int(11) DEFAULT NULL,
  `supplier_order_id` int(11) DEFAULT NULL,
  `movement_id` int(11) DEFAULT NULL,
  `pos_quantity` int(11) NOT NULL,
  `access_date` datetime DEFAULT NULL,
  `dispatch_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_rotation`
--

LOCK TABLES `stock_rotation` WRITE;
/*!40000 ALTER TABLE `stock_rotation` DISABLE KEYS */;
INSERT INTO `stock_rotation` VALUES (1,61,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(2,62,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(3,63,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(4,64,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(5,65,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(6,66,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(7,67,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(8,68,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(9,69,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(10,70,1,3,NULL,1,102,480,'2019-08-03 10:38:21',NULL),(11,131,1,3,NULL,1,102,200,'2019-08-03 10:38:21',NULL),(12,76,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(13,77,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(14,78,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(15,79,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(16,80,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(17,81,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(18,82,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(19,83,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(20,84,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(21,85,2,3,NULL,2,102,480,'2019-08-07 12:11:39',NULL),(22,132,2,3,NULL,2,102,200,'2019-08-07 12:11:39',NULL),(23,61,1,3,1,NULL,202,-60,NULL,'2019-08-27 11:10:32'),(24,76,2,3,2,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(25,61,1,3,3,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(26,76,2,3,4,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(27,61,1,3,5,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(28,76,2,3,6,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(29,61,1,3,7,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(30,76,2,3,8,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(31,61,1,3,9,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(32,76,2,3,10,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(33,61,1,3,11,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(34,76,2,3,12,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(35,62,1,3,13,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(36,77,2,3,14,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(37,62,1,3,15,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(38,77,2,3,16,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(39,62,1,3,17,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(40,77,2,3,18,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(41,62,1,3,19,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(42,77,2,3,20,NULL,202,-80,NULL,'2019-08-27 11:10:32'),(43,1,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(44,2,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(45,3,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(46,4,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(47,5,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(48,6,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(49,7,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(50,8,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(51,9,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(52,10,4,1,NULL,3,102,18,'2019-10-09 14:42:50',NULL),(53,31,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(54,32,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(55,33,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(56,34,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(57,35,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(58,36,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(59,37,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(60,38,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(61,39,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(62,40,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(63,41,5,1,NULL,4,102,25,'2019-10-09 14:42:50',NULL),(64,1,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(65,2,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(66,3,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(67,4,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(68,5,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(69,6,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(70,7,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(71,8,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(72,9,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(73,10,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(74,11,3,3,NULL,100002,102,48,'2022-06-23 13:25:18',NULL),(75,12,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(76,13,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(77,14,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(78,15,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(79,16,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(80,17,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(81,18,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(82,19,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(83,20,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(84,21,3,3,NULL,100002,102,48,'2022-06-23 13:25:19',NULL),(85,22,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL),(86,23,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL),(87,24,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL),(88,25,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL),(89,26,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL),(90,27,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL),(91,28,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL),(92,29,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL),(93,30,3,3,NULL,100002,102,48,'2022-06-23 13:25:20',NULL);
/*!40000 ALTER TABLE `stock_rotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_transfer_strategy`
--

DROP TABLE IF EXISTS `stock_transfer_strategy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_transfer_strategy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_transfer_strategy`
--

LOCK TABLES `stock_transfer_strategy` WRITE;
/*!40000 ALTER TABLE `stock_transfer_strategy` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfer_strategy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_zone`
--

DROP TABLE IF EXISTS `stock_zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_zone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_short_desc` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_zone`
--

LOCK TABLES `stock_zone` WRITE;
/*!40000 ALTER TABLE `stock_zone` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_zone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_zone_layout`
--

DROP TABLE IF EXISTS `stock_zone_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_zone_layout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_short_desc` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_coordinate` decimal(25,0) NOT NULL,
  `from_stock_nr` int(11) NOT NULL,
  `from_level1` int(11) NOT NULL,
  `from_level2` int(11) NOT NULL,
  `from_level3` int(11) NOT NULL,
  `from_level4` int(11) NOT NULL,
  `to_coordinate` decimal(25,0) NOT NULL,
  `to_level1` int(11) NOT NULL,
  `to_level2` int(11) NOT NULL,
  `to_level3` int(11) NOT NULL,
  `to_level4` int(11) NOT NULL,
  `sum_stock_loc` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_zone_layout`
--

LOCK TABLES `stock_zone_layout` WRITE;
/*!40000 ALTER TABLE `stock_zone_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_zone_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `supplier_nr` int(11) NOT NULL,
  `supplier_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_address_addition` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_address_street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_address_street_nr` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_address_country_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_address_zipcode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_address_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,1,70000,'4MBO International Electronic AG','','Fabrikstraße','45','DE','73207','Plochingen'),(2,2,70001,'Cyberport GmbH','','Am Brauhaus','5','DE','01099','Dresden'),(3,3,70002,'TestName','TestZusatz','TestStraße','123','DE','12345','TestStadt');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_order_pos`
--

DROP TABLE IF EXISTS `supplier_order_pos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_order_pos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_order_pos_quantity` decimal(11,3) NOT NULL,
  `supplier_order_id` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_order_pos`
--

LOCK TABLES `supplier_order_pos` WRITE;
/*!40000 ALTER TABLE `supplier_order_pos` DISABLE KEYS */;
INSERT INTO `supplier_order_pos` VALUES (1,5000.000,100001,1),(2,5000.000,100001,2),(3,5000.000,100002,3),(4,5000.000,100002,4);
/*!40000 ALTER TABLE `supplier_order_pos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_orders`
--

DROP TABLE IF EXISTS `supplier_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_order_id` int(11) NOT NULL,
  `usr_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_order_nr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_order_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_order_date` datetime DEFAULT NULL,
  `supplier_order_order_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_orders`
--

LOCK TABLES `supplier_orders` WRITE;
/*!40000 ALTER TABLE `supplier_orders` DISABLE KEYS */;
INSERT INTO `supplier_orders` VALUES (100001,100001,2,1,'EBE-01-100001','Telefon Aktion ALDI','2019-07-20 00:00:00','2019-07-15 00:00:00'),(100002,100002,2,2,'EBE-01-100002','PC Aktion Lidl','2019-08-03 00:00:00','2019-08-01 00:00:00');
/*!40000 ALTER TABLE `supplier_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_history`
--

DROP TABLE IF EXISTS `transport_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transport_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `su_id` int(11) NOT NULL,
  `tr_nr` int(11) NOT NULL,
  `tr_pos` int(11) NOT NULL,
  `tr_prio` int(11) NOT NULL DEFAULT 0,
  `article_nr` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tr_quantity` decimal(11,3) NOT NULL,
  `stock_coordinate` decimal(25,0) NOT NULL,
  `stock_nr` int(11) NOT NULL,
  `stock_level1` int(11) NOT NULL,
  `stock_level2` int(11) NOT NULL,
  `stock_level3` int(11) NOT NULL,
  `stock_level4` int(11) NOT NULL,
  `tr_access` datetime DEFAULT NULL,
  `tr_dispatch` datetime DEFAULT NULL,
  `tr_state` int(11) DEFAULT NULL,
  `order_username` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `booking_method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doc_id` int(11) NOT NULL,
  `order_nr` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_pos` int(11) NOT NULL,
  `charge` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loading_equipment` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmation_state` int(11) DEFAULT NULL,
  `tr_username` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tr_computer_ip` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tr_blocked` int(11) DEFAULT NULL,
  `tr_start_date` datetime DEFAULT NULL,
  `tr_edited` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tr_typ` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_history`
--

LOCK TABLES `transport_history` WRITE;
/*!40000 ALTER TABLE `transport_history` DISABLE KEYS */;
INSERT INTO `transport_history` VALUES (1,10000001,100,1,0,'60004',480.000,141000100010001,141,1,1,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(2,10000002,100,2,0,'60004',480.000,141000100020001,141,1,2,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(3,10000003,100,3,0,'60004',480.000,141000100030001,141,1,3,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(4,10000004,100,4,0,'60004',480.000,141000100040001,141,1,4,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(5,10000005,100,5,0,'60004',480.000,141000100050001,141,1,5,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(6,10000006,100,6,0,'60004',480.000,141000100060001,141,1,6,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(7,10000007,100,7,0,'60004',480.000,141000100070001,141,1,7,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(8,10000008,100,8,0,'60004',480.000,141000100080001,141,1,8,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(9,10000009,100,9,0,'60004',480.000,141000100090001,141,1,9,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(10,10000010,100,10,0,'60004',480.000,141000100100001,141,1,10,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(11,10000011,100,11,0,'60004',200.000,151000100010001,151,1,1,1,1,'2019-08-03 10:38:21',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'KARTON',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(12,10000012,101,1,0,'60008',480.000,141000200010001,141,2,1,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(13,10000013,101,2,0,'60008',480.000,141000200020001,141,2,2,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(14,10000014,101,3,0,'60008',480.000,141000200030001,141,2,3,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(15,10000015,101,4,0,'60008',480.000,141000200040001,141,2,4,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(16,10000016,101,5,0,'60008',480.000,141000200050001,141,2,5,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(17,10000017,101,6,0,'60008',480.000,141000200060001,141,2,6,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(18,10000018,101,7,0,'60008',480.000,141000200070001,141,2,7,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(19,10000019,101,8,0,'60008',480.000,141000200080001,141,2,8,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(20,10000020,101,9,0,'60008',480.000,141000200090001,141,2,9,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(21,10000021,101,10,0,'60008',480.000,141000200100001,141,2,10,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'PAL200',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(22,10000022,101,11,0,'60008',200.000,151000200010001,151,2,1,1,1,'2019-08-07 12:11:39',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',2,NULL,'KARTON',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(23,10000001,102,1,0,'60004',60.000,141000100010001,141,1,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710001,'VLS-01-710001',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(24,10000012,102,2,0,'60008',80.000,141000200010001,141,2,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710001,'VLS-01-710001',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(25,10000001,103,1,0,'60004',80.000,141000100010001,141,1,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710002,'VLS-01-710002',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(26,10000012,103,2,0,'60008',70.000,141000200010001,141,2,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710002,'VLS-01-710002',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(27,10000001,104,1,0,'60004',80.000,141000100010001,141,1,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710003,'VLS-01-710003',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(28,10000012,104,2,0,'60008',80.000,141000200010001,141,2,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710003,'VLS-01-710003',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(29,10000001,105,1,0,'60004',80.000,141000100010001,141,1,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710004,'VLS-01-710004',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(30,10000012,105,2,0,'60008',80.000,141000200010001,141,2,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710004,'VLS-01-710004',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(31,10000001,106,1,0,'60004',80.000,141000100010001,141,1,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710005,'VLS-01-710005',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(32,10000012,106,2,0,'60008',80.000,141000200010001,141,2,1,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710005,'VLS-01-710005',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(33,10000002,107,1,0,'60004',80.000,141000100020001,141,1,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710006,'VLS-01-710006',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(34,10000013,107,2,0,'60008',80.000,141000200020001,141,2,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710006,'VLS-01-710006',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(35,10000002,108,1,0,'60004',80.000,141000100020001,141,1,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710007,'VLS-01-710007',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(36,10000013,108,2,0,'60008',80.000,141000200020001,141,2,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710007,'VLS-01-710007',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(37,10000002,109,1,0,'60004',80.000,141000100020001,141,1,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710008,'VLS-01-710008',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(38,10000013,109,2,0,'60008',80.000,141000200020001,141,2,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710008,'VLS-01-710008',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(39,10000002,110,1,0,'60004',80.000,141000100020001,141,1,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710009,'VLS-01-710009',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(40,10000013,110,2,0,'60008',80.000,141000200020001,141,2,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710009,'VLS-01-710009',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(41,10000002,111,1,0,'60004',80.000,141000100020001,141,1,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710010,'VLS-01-710010',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(42,10000013,111,2,0,'60008',80.000,141000200020001,141,2,2,1,1,NULL,'2019-08-03 10:38:21',NULL,'karlfeld','WA202',710010,'VLS-01-710010',2,NULL,'PAL200',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(43,10000001,112,1,0,'60004',50.000,141000100010001,141,1,1,1,1,'2020-01-08 11:38:47',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(44,10000001,113,1,0,'60004',20.000,141000100010001,141,1,1,1,1,NULL,'2020-01-08 11:47:12',NULL,'karlfeld','WA202',710011,'VLS-01-710011',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(45,10000001,114,1,0,'60004',20.000,141000100010001,141,1,1,1,1,NULL,'2020-01-08 13:20:33',NULL,'karlfeld','WA202',710012,'VLS-01-710012',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(46,10000001,115,1,0,'60004',20.000,141000100010001,141,1,1,1,1,NULL,'2020-01-08 13:31:10',NULL,'karlfeld','WA202',710012,'VLS-01-710012',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2'),(47,10000001,116,1,0,'60004',50.000,141000100010001,141,1,1,1,1,'2020-01-09 10:26:41',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(48,10000001,117,1,0,'60004',50.000,141000100010001,141,1,1,1,1,'2020-01-09 10:58:13',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(49,10000002,118,1,0,'60004',50.000,141000100020001,141,1,2,1,1,'2020-01-09 10:58:13',NULL,NULL,'karlfeld','IN102',100001,'EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(50,10000001,119,1,0,'60004',20.000,141000100020001,141,1,2,1,1,NULL,'2020-01-08 13:31:10',NULL,'karlfeld','WA202',710012,'VLS-01-710012',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2');
/*!40000 ALTER TABLE `transport_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_request`
--

DROP TABLE IF EXISTS `transport_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transport_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `su_id` int(11) NOT NULL,
  `tr_nr` int(11) NOT NULL,
  `tr_pos` int(11) NOT NULL,
  `tr_prio` int(11) NOT NULL DEFAULT 0,
  `article_nr` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tr_quantity` decimal(11,3) NOT NULL,
  `stock_coordinate` decimal(25,0) NOT NULL,
  `stock_nr` int(11) NOT NULL,
  `stock_level1` int(11) NOT NULL,
  `stock_level2` int(11) NOT NULL,
  `stock_level3` int(11) NOT NULL,
  `stock_level4` int(11) NOT NULL,
  `tr_access` datetime DEFAULT NULL,
  `tr_dispatch` datetime DEFAULT NULL,
  `tr_state` int(11) DEFAULT NULL,
  `order_username` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `booking_method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_nr` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_pos` int(11) NOT NULL,
  `charge` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loading_equipment` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmation_state` int(11) DEFAULT NULL,
  `tr_username` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tr_computer_ip` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tr_blocked` int(11) DEFAULT NULL,
  `tr_start_date` datetime DEFAULT NULL,
  `tr_edited` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tr_typ` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_request`
--

LOCK TABLES `transport_request` WRITE;
/*!40000 ALTER TABLE `transport_request` DISABLE KEYS */;
INSERT INTO `transport_request` VALUES (51,10000001,120,1,0,'60004',480.000,14100100100100100,141,1,1,1,1,'2022-02-19 14:05:12',NULL,NULL,'karlfeld','IN102','EBE-01-100001',1,NULL,'PAL100',NULL,'brunolag','192.168.1.52',NULL,NULL,NULL,'1'),(52,10000001,121,1,0,'60004',40.000,14100100100100100,141,1,1,1,1,NULL,'2022-02-19 15:22:37',NULL,'karlfeld','WA202','VLS-01-710012',1,NULL,'PAL100',NULL,'jocash','192.168.1.55',NULL,NULL,NULL,'2');
/*!40000 ALTER TABLE `transport_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`roles`)),
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','[\"ROLE_SUPER_ADMIN\"]','$2y$13$mjtovsCX6wBG0aLlsFY2We92TKaJ9v/Ol2FSMfV0FFSmQH6Cq7L4G','Rene','Irrgang'),(2,'brunolag','[\"ROLE_ADMIN\"]','brunolag2019','Bruno','Lagerfeld'),(3,'karlfeld','[\"ROLE_ADMIN\"]','karlfeld2019','Karl','Feldlager'),(4,'jocash','[\"ROLE_ADMIN\"]','jocash2019','Johnny','Cash'),(5,'rirrgang','[\"ROLE_ADMIN\"]','$2y$13$mjtovsCX6wBG0aLlsFY2We92TKaJ9v/Ol2FSMfV0FFSmQH6Cq7L4G','Rene','Irrgang');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-29 12:44:28
